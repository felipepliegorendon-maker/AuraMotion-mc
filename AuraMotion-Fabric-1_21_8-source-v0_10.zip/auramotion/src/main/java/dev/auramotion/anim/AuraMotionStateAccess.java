package dev.auramotion.anim;

/** Duck interface mixed into PlayerEntityRenderState to carry motion data to the model. */
public interface AuraMotionStateAccess {
    PlayerMotionState auramotion$getMotion();

    void auramotion$setMotion(PlayerMotionState motion);
}
