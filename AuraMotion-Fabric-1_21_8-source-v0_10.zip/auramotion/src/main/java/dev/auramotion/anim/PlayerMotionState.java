package dev.auramotion.anim;

/** Smoothed per-player motion values. Written in updateRenderState, read by the model mixin. */
public final class PlayerMotionState {
    // Bookkeeping
    long lastNanos;
    double lastX, lastY, lastZ;
    boolean wasOnGround = true;
    float airTime;
    float peakFall;
    long lastSeenNanos;
    float lastYaw;
    boolean yawInit;

    /** Per-player phase offset so idle motion is not synchronized between players. */
    public float phase;
    /** True only for the local player (emotes are local, visual only). */
    public boolean local;

    // Smoothed outputs, all in 0..1
    /** 1 = effects fully active, 0 = suppressed (riding, using item, climbing...). */
    public float master = 1.0F;
    /** 1 = arms free, 0 = arm is busy swinging/attacking. */
    public float armWeight = 1.0F;
    public float lean;
    public float air;
    public float rise;
    public float fall;
    public float land;
    /** Signed, -1..1: smoothed turning speed (follow-through when the player rotates). */
    public float turn;
    /** Raw hand swing progress 0..1 (attack / mining), 0 when not swinging. */
    public float swing;
    /** 0 = other, 1 = sword, 2 = pickaxe/axe/shovel/hoe. */
    public int swingStyle;
    public boolean swingRight = true;
    // Only filled when bentLimbs is on.
    public boolean chestArmor, legArmor, rightHandBusy, leftHandBusy;
}
