package dev.auramotion.anim;

import dev.auramotion.config.AuraMotionConfig;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Applies small additive rotations on top of the vanilla pose.
 * Rotation-only on purpose: pivots are left alone to stay compatible with other mods.
 * Sign convention: body/head pitch + = forward; right arm roll + / left arm roll - = outward;
 * arm pitch - = forward/up; body yaw - = right shoulder forward.
 */
public final class SecondaryMotion {
    private SecondaryMotion() {
    }

    public static void apply(PlayerEntityModel model, PlayerMotionState s, float age,
                             float limbAmplitude, float limbProgress) {
        AuraMotionConfig c = AuraMotionConfig.get();
        float k = c.intensity * s.master;
        if (k <= 0.001F) {
            return;
        }
        float armK = k * s.armWeight;
        float movement = MathHelper.clamp(limbAmplitude, 0.0F, 1.0F);

        if (c.idleBreathing) {
            float phase = age * 0.075F + s.phase;
            float idleWeight = 1.0F - movement;
            float idle = MathHelper.sin(phase) * 0.018F * idleWeight * armK;
            model.rightArm.roll += idle;
            model.leftArm.roll -= idle;
            model.body.yaw += MathHelper.sin(phase * 0.5F) * 0.006F * idleWeight * k;
        }

        if (c.walkSway) {
            float gait = MathHelper.sin(limbProgress * 0.5F);
            model.body.yaw += gait * 0.012F * movement * k;
        }

        boolean athletic = !"classic".equals(c.runStyle);
        if (athletic) {
            applyAthletic(model, s, c, k, movement);
        }

        if (!athletic && c.sprintLean && s.lean > 0.001F) {
            float lean = s.lean * k;
            model.body.pitch += lean * 0.14F;
            model.head.pitch -= lean * 0.10F; // keep the gaze level
        }

        if (!athletic && c.runDetail && movement > 0.05F) {
            float run = s.lean; // 0 walking .. 1 sprinting
            float w = movement * (0.35F + 0.65F * run) * k;
            // Stronger shoulder/hip drive (scales the vanilla swing, so it stays in phase).
            float armDrive = 1.0F + 0.30F * run * armK;
            model.rightArm.pitch *= armDrive;
            model.leftArm.pitch *= armDrive;
            float legDrive = 1.0F + 0.15F * run * k;
            model.rightLeg.pitch *= legDrive;
            model.leftLeg.pitch *= legDrive;
            // Torso counter-twist follows the arms; head keeps looking forward.
            float twist = (model.rightArm.pitch - model.leftArm.pitch) * 0.05F * w * s.armWeight;
            model.body.yaw += twist;
            model.head.yaw -= twist;
            // Hip sway follows the legs.
            float sway = (model.rightLeg.pitch - model.leftLeg.pitch) * 0.0125F * w;
            model.body.roll += sway;
            model.head.roll -= sway;
            // Arms open slightly when sprinting.
            float out = 0.07F * run * armK;
            model.rightArm.roll += out;
            model.leftArm.roll -= out;
        }

        if (c.turnFollow && Math.abs(s.turn) > 0.002F) {
            // Torso lags slightly behind the turn; arms trail outward on the swing side.
            model.body.yaw -= s.turn * 0.10F * k;
            float trail = s.turn * 0.12F * armK;
            model.rightArm.roll += Math.max(0.0F, -trail);
            model.leftArm.roll -= Math.max(0.0F, trail);
        }

        if (c.airPose && s.air > 0.001F) {
            float out = (0.10F * s.air + 0.35F * s.fall) * armK;
            model.rightArm.roll += out;
            model.leftArm.roll -= out;
            float up = s.rise * 0.28F * armK;
            model.rightArm.pitch -= up;
            model.leftArm.pitch -= up;
        }

        if (c.landingImpact && s.land > 0.001F) {
            float land = s.land * k;
            model.body.pitch += land * 0.18F;
            model.head.pitch -= land * 0.10F;
            float spread = land * 0.20F * s.armWeight;
            model.rightArm.roll += spread;
            model.leftArm.roll -= spread;
        }

        if (c.swingAnimations && s.swing > 0.001F) {
            applySwing(model, s, k);
        }
    }

    /**
     * Athletic run: forward lean, arms held forward and pumping (bent-arm look), legs with a longer trailing kick,
     * counter-twisting torso, head bob. Limbs are rigid in the vanilla model (no elbows/knees), so this is an
     * approximation done with rotations only. u is the vanilla swing signal (+1 = right arm fully forward).
     */
    private static void applyAthletic(PlayerEntityModel m, PlayerMotionState s, AuraMotionConfig c,
                                      float k, float movement) {
        RunProfile p = RunProfile.of(c.runStyle);
        float run = s.lean; // 0 jog .. 1 sprint
        float rw = movement * (0.25F + 0.75F * run); // how much of the run pose applies
        float jog = movement * (1.0F - run);

        if (c.sprintLean) {
            float lean = (p.leanJog * jog + p.leanSprint * run) * k;
            m.body.pitch += lean;
            m.head.pitch -= lean * p.headComp; // 0.85 keeps the gaze level, lower lets the head follow the lean
        }
        if (!c.runDetail || rw < 0.02F) {
            return;
        }

        float t = MathHelper.clamp(rw * k, 0.0F, 1.0F);
        float ta = t * s.armWeight;
        float u = (m.leftArm.pitch - m.rightArm.pitch) * 0.5F;

        // Arms: held forward, swing mostly in front of the body, elbows tucked toward the torso.
        m.rightArm.pitch = MathHelper.lerp(ta, m.rightArm.pitch, pump(u, p));
        m.leftArm.pitch = MathHelper.lerp(ta, m.leftArm.pitch, pump(-u, p));
        m.rightArm.roll -= p.tuck * ta;
        m.leftArm.roll += p.tuck * ta;

        // Legs: longer trailing kick, slightly higher knee.
        m.rightLeg.pitch = kick(m.rightLeg.pitch, t, p);
        m.leftLeg.pitch = kick(m.leftLeg.pitch, t, p);

        // Torso counter-twist, head stays level; bob twice per stride; hip sway.
        float twist = -u * p.twist * rw * k * s.armWeight;
        m.body.yaw += twist;
        m.head.yaw -= twist;
        m.head.pitch += (0.5F - Math.abs(u)) * p.bob * rw * k;
        float sway = (m.rightLeg.pitch - m.leftLeg.pitch) * p.sway * rw * k;
        m.body.roll += sway;
        m.head.roll -= sway;
    }

    private static float pump(float u, RunProfile p) {
        return u > 0.0F ? -p.armBase - p.armFwd * u : -p.armBase - p.armBack * u;
    }

    private static float kick(float pitch, float t, RunProfile p) {
        return pitch > 0.0F ? pitch * (1.0F + p.kickBack * t) : pitch * (1.0F + p.kickFront * t);
    }

    /** Follow-through on top of vanilla's swing (peak of vanilla's strike is around p = 0.2). */
    private static void applySwing(PlayerEntityModel model, PlayerMotionState s, float k) {
        float p = MathHelper.clamp(s.swing, 0.0F, 1.0F);
        float inv = 1.0F - p;
        float strike = MathHelper.sin((1.0F - inv * inv * inv) * MathHelper.PI); // matches vanilla's curve
        float bell = MathHelper.sin(p * MathHelper.PI); // slower body weight shift

        float armExtra, out, bodyAmt, headAmt, lunge;
        switch (s.swingStyle) {
            case 1 -> { armExtra = 0.15F; out = 0.20F; bodyAmt = 0.10F; headAmt = 0.04F; lunge = 0.22F; } // sword slash
            case 2 -> { armExtra = 0.35F; out = 0.08F; bodyAmt = 0.18F; headAmt = 0.10F; lunge = 0.12F; } // chop / dig
            default -> { armExtra = 0.10F; out = 0.08F; bodyAmt = 0.05F; headAmt = 0.02F; lunge = 0.08F; }
        }

        ModelPart arm = s.swingRight ? model.rightArm : model.leftArm;
        float side = s.swingRight ? 1.0F : -1.0F;
        arm.pitch -= strike * armExtra * k;
        arm.roll += side * strike * out * k;

        model.body.pitch += bell * bodyAmt * k;
        model.head.pitch += bell * headAmt * k;

        // Weight shift: the leg opposite the swinging arm steps forward.
        ModelPart front = s.swingRight ? model.leftLeg : model.rightLeg;
        ModelPart back = s.swingRight ? model.rightLeg : model.leftLeg;
        front.pitch -= bell * lunge * k;
        back.pitch += bell * lunge * 0.6F * k;
    }
}
