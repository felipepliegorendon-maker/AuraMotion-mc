package dev.auramotion.anim;

import dev.auramotion.config.AuraMotionConfig;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Tracks lightweight, frame-rate independent motion data per player.
 * Render thread only. No exp()/sqrt() in the hot path; players beyond maxDistance are skipped.
 */
public final class MotionTracker {
    private static final Int2ObjectOpenHashMap<PlayerMotionState> STATES = new Int2ObjectOpenHashMap<>();
    private static int calls;

    private MotionTracker() {
    }

    public static void clear() {
        STATES.clear();
    }

    /** @return the smoothed state for this player, or null when AuraMotion is off or the player is far away. */
    public static PlayerMotionState update(AbstractClientPlayerEntity player, float tickDelta) {
        AuraMotionConfig cfg = AuraMotionConfig.get();
        if (!cfg.enabled || cfg.intensity <= 0.0F) {
            return null;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean local = player == mc.player;
        if (!local && mc.player != null) {
            double max = cfg.maxDistance;
            if (player.squaredDistanceTo(mc.player) > max * max) {
                return null; // distance LOD: zero work for far players
            }
        }
        long t0 = System.nanoTime();
        PlayerMotionState s = compute(player, tickDelta, local, t0);
        PerfStats.add(System.nanoTime() - t0);
        return s;
    }

    private static PlayerMotionState compute(AbstractClientPlayerEntity player, float tickDelta, boolean local, long now) {
        int id = player.getId();
        PlayerMotionState s = STATES.get(id);
        if (s == null) {
            s = new PlayerMotionState();
            s.phase = (id & 1023) / 1023.0F * MathHelper.TAU;
            STATES.put(id, s);
        }
        s.lastSeenNanos = now;
        s.local = local;

        if ((++calls & 511) == 0) {
            long limit = now - 10_000_000_000L;
            STATES.values().removeIf(v -> v.lastSeenNanos < limit);
        }

        Vec3d pos = player.getLerpedPos(tickDelta);
        if (s.lastNanos == 0L) {
            s.lastNanos = now;
            s.lastX = pos.x;
            s.lastY = pos.y;
            s.lastZ = pos.z;
            return s;
        }

        float dt = (now - s.lastNanos) / 1.0E9F;
        if (dt < 0.0005F) {
            return s; // Same frame (or extremely fast); keep current values.
        }
        dt = Math.min(dt, 0.25F);
        s.lastNanos = now;

        double dx = pos.x - s.lastX;
        double dy = pos.y - s.lastY;
        double dz = pos.z - s.lastZ;
        s.lastX = pos.x;
        s.lastY = pos.y;
        s.lastZ = pos.z;

        // Teleport / respawn / dimension change: drop transient state.
        if (dx * dx + dy * dy + dz * dz > 64.0D) {
            s.air = s.rise = s.fall = s.land = s.lean = s.turn = s.swing = 0.0F;
            s.yawInit = false;
            s.airTime = 0.0F;
            s.peakFall = 0.0F;
            s.wasOnGround = true;
            return s;
        }

        // Turning speed (deg/s -> -1..1), smoothed. Wrapped so 359 -> 1 is a small step.
        float yaw = player.getYaw(tickDelta);
        float turnTarget = 0.0F;
        if (s.yawInit) {
            turnTarget = MathHelper.clamp(MathHelper.wrapDegrees(yaw - s.lastYaw) / dt / 540.0F, -1.0F, 1.0F);
        }
        s.lastYaw = yaw;
        s.yawInit = true;
        s.turn = approach(s.turn, turnTarget, 9.0F, dt);

        // Velocities in blocks per tick (vanilla units).
        float vy = (float) (dy / dt / 20.0D);
        float speed = (float) (Math.sqrt(dx * dx + dz * dz) / dt / 20.0D);

        boolean onGround = player.isOnGround();
        boolean busy = player.isUsingItem() || player.hasVehicle() || player.isClimbing()
                || player.isTouchingWater();
        boolean airborne = !onGround && !busy;

        // Moving, jumping, sneaking or interacting cancels an emote.
        if (local && AnimationManager.isActive()
                && (speed > 0.04F || !onGround || busy || player.isSneaking())) {
            AnimationManager.stop();
        }

        // Master weight: fade effects out instead of popping.
        s.master = approach(s.master, busy ? 0.0F : 1.0F, 12.0F, dt);

        // Attack / mining swing.
        float swingP = player.getHandSwingProgress(tickDelta);
        s.swing = swingP;
        if (swingP > 0.0F) {
            ItemStack held = player.getMainHandStack();
            s.swingStyle = held.isIn(ItemTags.SWORDS) ? 1
                    : (held.isIn(ItemTags.PICKAXES) || held.isIn(ItemTags.AXES)
                    || held.isIn(ItemTags.SHOVELS) || held.isIn(ItemTags.HOES)) ? 2 : 0;
            s.swingRight = player.getMainArm() == Arm.RIGHT;
        }
        if (AuraMotionConfig.get().bentLimbs) {
            s.chestArmor = !player.getEquippedStack(EquipmentSlot.CHEST).isEmpty();
            s.legArmor = !player.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                    || !player.getEquippedStack(EquipmentSlot.FEET).isEmpty();
            boolean mainHeld = !player.getMainHandStack().isEmpty();
            boolean offHeld = !player.getOffHandStack().isEmpty();
            boolean mainRight = player.getMainArm() == Arm.RIGHT;
            s.rightHandBusy = mainRight ? mainHeld : offHeld;
            s.leftHandBusy = mainRight ? offHeld : mainHeld;
        }
        // Idle/air arm additions fade out while the arm is busy swinging.
        s.armWeight = approach(s.armWeight, swingP > 0.0F ? 0.0F : 1.0F, 18.0F, dt);

        // Sprint lean.
        float leanTarget = (player.isSprinting() && onGround && !busy)
                ? MathHelper.clamp(speed / 0.28F, 0.0F, 1.0F) : 0.0F;
        s.lean = approach(s.lean, leanTarget, 8.0F, dt);

        // Airborne weight with a small delay to ignore stairs/slabs/step-downs.
        s.airTime = airborne ? s.airTime + dt : 0.0F;
        boolean inAir = s.airTime > 0.12F;
        s.air = approach(s.air, inAir ? 1.0F : 0.0F, inAir ? 10.0F : 14.0F, dt);
        s.rise = approach(s.rise, inAir ? MathHelper.clamp(vy / 0.42F, 0.0F, 1.0F) : 0.0F, 12.0F, dt);
        s.fall = approach(s.fall, inAir ? MathHelper.clamp(-vy / 0.9F, 0.0F, 1.0F) : 0.0F, 10.0F, dt);

        if (inAir) {
            s.peakFall = Math.min(s.peakFall, vy);
        }

        // Landing impulse proportional to the fall speed reached.
        if (onGround && !s.wasOnGround) {
            if (s.peakFall < -0.2F) {
                float impulse = MathHelper.clamp((-s.peakFall - 0.2F) / 0.7F, 0.0F, 1.0F);
                s.land = Math.max(s.land, 0.25F + 0.75F * impulse);
            }
            s.peakFall = 0.0F;
        }
        s.wasOnGround = onGround;

        s.land /= 1.0F + 6.5F * dt; // cheap exponential-like decay
        if (s.land < 0.005F) {
            s.land = 0.0F;
        }
        return s;
    }

    /** Frame-rate independent smoothing without exp(): implicit Euler step. */
    private static float approach(float current, float target, float rate, float dt) {
        float x = rate * dt;
        return current + (target - current) * (x / (1.0F + x));
    }
}
