# AuraMotion — Fabric 1.21.8 (v0.10.0)

Mod **client-only** de animaciones de jugador en tercera persona, con la misma idea general que Fancy Player Animation (movimiento más fluido y vivo) pero con código **original**. No es un port.

## Qué hace (v0.3)
- Respiración/idle sutil y balanceo del torso al caminar (ya estaba en v0.2).
- **Inclinación al correr (sprint)**: el torso se inclina y la cabeza compensa.
- **Pose en el aire**: brazos hacia fuera al caer, hacia delante al saltar.
- **Impacto al aterrizar**: proporcional a la velocidad de caída.
- **Seguimiento al girar (v0.4)**: el torso se retrasa un poco y los brazos se abren hacia el lado contrario al giro. Signos sin verificar visualmente; si se ve al revés, cambiar el signo en `SecondaryMotion`.
- **Carrera atlética (v0.7, por defecto)**: inclinación fuerte hacia delante, brazos adelantados que bombean al estilo de codos doblados, patada trasera más larga, torso que gira en contra, cabeza estable con rebote. Cambia con `/auramotion runstyle fresh|athletic|action|classic` (`runStyle` en el JSON).
- **Carrera fresh (v0.10, por defecto)**: calibrada con la imagen de referencia: inclinación fuerte con la cabeza siguiéndola, codos a ~90° con los puños al pecho y codos algo abiertos, zancada ancha y pierna trasera pateada hacia arriba. **Necesita `bend on`** para los codos y rodillas; sin eso solo se aproxima con rotaciones.
- **Carrera action (v0.9)**: más energética, inspirada en el "feel" de Actions & Stuff: inclinación más profunda, brazos que empujan más, rodillas altas, codos y rodillas más doblados con `bend on`. `/auramotion runstyle action`.
- **Carrera clásica (v0.6)**: más impulso de brazos y piernas al correr, torsión contraria del torso (la cabeza mira al frente), balanceo de cadera y brazos que se abren un poco.
- **Golpes y minería (v0.6)**: seguimiento del movimiento al atacar o picar con espada (tajo), pico/hacha/pala/azada (golpe cargado). Desplazamiento de peso con las piernas y inclinación del torso, encima de la animación vanilla.
- Transiciones suavizadas e independientes de los FPS; cada jugador tiene fase propia.
- Se desactiva con suavidad al usar ítems, montar, trepar o nadar; no pisa el golpe de ataque.
- Sin primera persona, sin red, sin tocar mecánicas de combate. Solo rotaciones aditivas (no mueve pivotes).

## Emotes por JSON (v0.5)
Se leen de `config/auramotion/animations/*.json` (al primer arranque se crean `wave` y `bow`). Solo los ve el jugador local, sin red. Se cancelan al moverte, saltar, agacharte o usar un ítem. Se ven en tercera persona (F5).

```json
{
  "length": 2.0,
  "loop": false,
  "tracks": {
    "rightArm": [
      {"t": 0.0, "pitch": 0,    "roll": 0},
      {"t": 0.5, "pitch": -150, "roll": 30},
      {"t": 2.0, "pitch": 0,    "roll": 0}
    ]
  }
}
```
Partes: `head`, `body`, `rightArm`, `leftArm`, `rightLeg`, `leftLeg`. Ángulos en grados (`pitch`, `yaw`, `roll`); las partes sin pista no se tocan.

## Comandos (en el juego)
- `/auramotion runstyle fresh|athletic|action|classic`
- `/auramotion perf` muestra cuánta CPU gasta el mod (µs por llamada y ms por segundo); úsalo con y sin `toggle` para comparar FPS
- `/auramotion play <emote>`, `/auramotion stop`, `/auramotion list`
- `/auramotion toggle` activa/desactiva
- `/auramotion reload` recarga `config/auramotion.json`
- `/auramotion intensity <0-2>` multiplicador global

## Config (`config/auramotion.json`)
`enabled`, `intensity`, `idleBreathing`, `walkSway`, `sprintLean`, `airPose`, `landingImpact`, `turnFollow`, `runDetail`, `swingAnimations`, `maxDistance`

## Compilar
Java 21 + Gradle 8.14: `gradle build` → `build/libs/`.
Sin PC: sube la carpeta a un repo de GitHub; el workflow `.github/workflows/build.yml` compila y deja el JAR como artefacto descargable.

## Estado
**Sin compilar ni probar** (el entorno de desarrollo no tiene acceso a las dependencias). Si falla un mixin, el log mostrará el método o descriptor que no coincide con Yarn 1.21.8; hay que corregirlo ahí.

## Codos y rodillas reales (v0.8, EXPERIMENTAL, apagado por defecto)
`/auramotion bend on|off` (o `bentLimbs` en el JSON) y reinicia el juego (o F3+T). Parte cada brazo y pierna en dos mitades al cargar el modelo para poder doblarlas.
- Armadura e ítems usan modelos rígidos: el codo no se dobla si llevas pechera o sostienes algo con ese brazo, ni la rodilla si llevas pantalones o botas.
- Si el nombre del método del modelo cambia en 1.21.8, simplemente no hace nada (vuelve al modelo vanilla).
- Puede chocar con mods que cambian el modelo del jugador.

## Límite conocido
El modelo vanilla tiene brazos y piernas rígidos (sin codos ni rodillas). La carrera atlética los imita con rotaciones; para codos y rodillas reales haría falta un modelo con extremidades divididas (como hacen los packs con modelos de entidad personalizados), que cuesta más rendimiento.

## Pendiente / ideas
- Animaciones personalizadas por JSON (emotes), con API para otros mods
- Cabeza/cuello con retardo (necesita historial de rotación)
- Menú de ajustes (Mod Menu) si no se quiere depender solo de comandos

## Rendimiento (pensado para equipos básicos)
- Los jugadores a más de `maxDistance` bloques (24 por defecto) no gastan nada.
- Sin `exp()` ni asignaciones en el camino caliente; mapa por id de entidad (fastutil); solo rotaciones.
- `/auramotion perf` mide el costo real en tu dispositivo. Si bajan los FPS, baja `maxDistance`, desactiva `runDetail`/`turnFollow` o pon `intensity` en 0.
- No se han medido FPS en un dispositivo real todavía: hay que probarlo.
