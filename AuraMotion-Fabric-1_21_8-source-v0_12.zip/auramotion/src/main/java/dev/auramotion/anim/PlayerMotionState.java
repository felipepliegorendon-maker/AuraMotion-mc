package dev.auramotion.anim;

/** Smoothed per-player motion values. Written in updateRenderState, read by the model mixin. */
public final class PlayerMotionState {
    // Bookkeeping
    long lastNanos;
    double lastX, lastY, lastZ;
    boolean wasOnGround = true;
    float airTime;
    float peakFall;
    long lastSeenNanos;
    float lastYaw;
    boolean yawInit;

    /** Per-player phase offset so idle motion is not synchronized between players. */
    public float phase;
    /** True only for the local player (emotes are local, visual only). */
    public boolean local;

    // Smoothed outputs, all in 0..1
    /** 1 = effects fully active, 0 = suppressed (riding, using item, climbing...). */
    public float master = 1.0F;
    /** 1 = arms free, 0 = arm is busy swinging/attacking. */
    public float armWeight = 1.0F;
    public float lean;
    public float air;
    public float rise;
    public float fall;
    public float land;
    /** Signed, -1..1: smoothed turning speed (follow-through when the player rotates). */
    public float turn;
    /** Movement relative to where the player looks: fwd +1 forward / -1 backward, side +1 right / -1 left. */
    public float fwd, side;
    /** 0..1 climbing weight and its phase (advances with vertical movement). */
    public float climb, climbPhase;
    /** 0..1 item-use weight; kind: 1 eat, 2 bow/crossbow, 3 drink. */
    public float useW;
    /** Riding: weight, mount kind (1 horse, 2 boat, 3 other), smoothed mount speed and gait phase. */
    public float rideW, rideSpeed, ridePhase;
    public int mountKind;
    int vehicleId = Integer.MIN_VALUE;
    /** Gliding (elytra) and its weight; shield blocking weight; damage flinch 0..1; fishing weight. */
    public boolean glide;
    public float glideW, blockW, hurt, fishW;
    public int useKind;
    /** Raw hand swing progress 0..1 (attack / mining), 0 when not swinging. */
    public float swing;
    /** 0 = other, 1 = sword, 2 = pickaxe/axe/shovel/hoe. */
    public int swingStyle;
    public boolean swingRight = true;
    // Only filled when bentLimbs is on.
    public boolean chestArmor, legArmor, rightHandBusy, leftHandBusy;
}
