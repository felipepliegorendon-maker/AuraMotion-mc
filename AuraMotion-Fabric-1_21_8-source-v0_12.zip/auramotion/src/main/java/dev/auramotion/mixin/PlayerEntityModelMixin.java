package dev.auramotion.mixin;

import dev.auramotion.anim.AnimationManager;
import dev.auramotion.anim.AuraMotionStateAccess;
import dev.auramotion.anim.BentLimbs;
import dev.auramotion.anim.PerfStats;
import dev.auramotion.anim.PlayerMotionState;
import dev.auramotion.anim.SecondaryMotion;
import dev.auramotion.config.AuraMotionConfig;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.EntityPose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Additive third-person overlay. Vanilla keeps the base pose (walk, swim, sneak, attack, use item).
 * The motion object is only attached by PlayerEntityRendererMixin, so first-person arms
 * (which never go through that path) are untouched.
 */
@Mixin(PlayerEntityModel.class)
public abstract class PlayerEntityModelMixin {
    @Unique
    private BentLimbs.Parts auramotion$bend;
    @Unique
    private boolean auramotion$bendChecked;

    /** Experimental: split limbs at bake time (no-op unless bentLimbs is on). */
    @Inject(
            method = "getModelData(Lnet/minecraft/client/model/Dilation;Z)Lnet/minecraft/client/model/ModelData;",
            at = @At("RETURN")
    )
    private static void auramotion$split(Dilation dilation, boolean slim, CallbackInfoReturnable<ModelData> cir) {
        BentLimbs.split(cir.getReturnValue(), dilation, slim);
    }

    @Inject(
            method = "setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V",
            at = @At("TAIL")
    )
    private void auramotion$apply(PlayerEntityRenderState state, CallbackInfo ci) {
        AuraMotionConfig cfg = AuraMotionConfig.get();
        PlayerEntityModel model = (PlayerEntityModel) (Object) this;
        boolean bend = cfg.bentLimbs;
        if (bend && !auramotion$bendChecked) {
            auramotion$bendChecked = true;
            auramotion$bend = BentLimbs.resolve(model);
        }

        PlayerMotionState motion = ((AuraMotionStateAccess) (Object) state).auramotion$getMotion();
        int poseId = state.isInPose(EntityPose.STANDING) ? 0
                : state.isInPose(EntityPose.CROUCHING) ? 1
                : state.isInPose(EntityPose.SWIMMING) ? 2
                : (motion != null && motion.glide) ? 3 : -1;
        if (motion == null || poseId < 0) {
            if (bend && auramotion$bend != null) {
                BentLimbs.reset(auramotion$bend);
            }
            return;
        }
        long t0 = System.nanoTime();
        if (poseId == 0) {
            SecondaryMotion.apply(model, motion, state.age,
                    state.limbSwingAmplitude, state.limbSwingAnimationProgress);
        } else {
            SecondaryMotion.applyOther(model, motion, poseId, state.age, state.limbSwingAmplitude);
        }
        if (bend && poseId == 0 && auramotion$bend != null) {
            float movement = Math.max(0.0F, Math.min(1.0F, state.limbSwingAmplitude));
            BentLimbs.pose(model, auramotion$bend, motion, movement, cfg.intensity * motion.master);
        }
        PerfStats.add(System.nanoTime() - t0);
        if (motion.local) {
            AnimationManager.apply(model);
        }
    }
}
